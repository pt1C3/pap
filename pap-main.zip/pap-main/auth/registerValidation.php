<?php
    include 'db.php';

    $username  = $_POST['username'];
    $password  = $_POST['password'];
    $confirmpassword  = $_POST['confirmpassword'];
    
    



?>